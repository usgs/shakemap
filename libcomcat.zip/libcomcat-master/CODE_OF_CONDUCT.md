Code of Conduct
===============

All contributions to- and interactions surrounding- this project will abide by
the [USGS Code of Scientific Conduct][1].



[1]: https://www2.usgs.gov/fsp/fsp_code_of_scientific_conduct.asp