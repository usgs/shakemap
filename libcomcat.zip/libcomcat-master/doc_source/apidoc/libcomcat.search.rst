libcomcat\.search
========================

.. automodule:: libcomcat.search
    :members:
    :undoc-members:
    :show-inheritance:
