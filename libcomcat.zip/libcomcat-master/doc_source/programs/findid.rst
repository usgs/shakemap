.. _findid:

findid
==========

.. argparse::
   :filename: findid
   :func: get_parser
   :prog: findid

