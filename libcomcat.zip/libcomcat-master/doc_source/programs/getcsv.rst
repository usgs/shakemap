.. _getcsv:

getcsv
===========

.. argparse::
   :filename: ./getcsv
   :func: get_parser
   :prog: getcsv

