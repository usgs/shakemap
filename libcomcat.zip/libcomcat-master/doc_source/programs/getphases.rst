.. _getphases:

getphases
==========

.. argparse::
   :filename: getphases
   :func: get_parser
   :prog: getphases

