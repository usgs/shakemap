.. _getproduct:

getproduct
==========

.. argparse::
   :filename: getproduct
   :func: get_parser
   :prog: getproduct

